
const router=require("express").Router()
const jwt=require("jsonwebtoken")

router.post("/login",(req,res)=>{

 const {username}=req.body

 const token=jwt.sign({username,role:"admin"},process.env.JWT_SECRET)

 res.json({
  user:{username,role:"admin"},
  token
 })

})

module.exports=router
