
const router=require("express").Router()
const excel=require("../services/excel")

module.exports=(io)=>{

 router.get("/worksheets",async(req,res)=>{

  const sheets=await excel.getSheets()
  res.json(sheets)

 })

 router.get("/:sheet",async(req,res)=>{

  const rows=await excel.read(req.params.sheet)
  res.json(rows)

 })

 router.delete("/:sheet/:id",async(req,res)=>{

  await excel.deleteRow(req.params.sheet,req.params.id)

  io.emit("excelUpdated",{sheet:req.params.sheet})

  res.json({status:"deleted"})

 })

 return router
}
