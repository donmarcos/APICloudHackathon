
<template>

<div style="display:flex">

<div style="width:220px;background:#2c3e50;color:white;height:100vh">

<h3 style="padding:10px">Enterprise CRUD</h3>

<ul>
<li><router-link to="/dashboard">Dashboard</router-link></li>
</ul>

</div>

<div style="flex:1;padding:20px">
<router-view/>
</div>

</div>

</template>
