
<template>

<div>

<h2>Login</h2>

<input v-model="username" placeholder="username"/>
<input v-model="password" type="password"/>

<button @click="login">Login</button>

</div>

</template>

<script setup>

import {ref} from "vue"
import {useRouter} from "vue-router"
import {useAuth} from "../stores/auth"

const username=ref("")
const password=ref("")
const router=useRouter()
const auth=useAuth()

async function login(){

 await auth.login(username.value,password.value)

 router.push("/dashboard")

}

</script>
