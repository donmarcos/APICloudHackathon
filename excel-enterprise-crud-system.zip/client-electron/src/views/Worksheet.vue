
<template>

<div>

<h2>{{sheet}}</h2>

<DataGrid
 :rows="rows"
 :headers="headers"
 @delete="remove"
/>

</div>

</template>

<script setup>

import {ref,onMounted} from "vue"
import {useRoute} from "vue-router"
import api from "../services/api"
import DataGrid from "../components/DataGrid.vue"

const route=useRoute()
const sheet=route.params.name

const rows=ref([])
const headers=ref([])

async function load(){

 const res=await api.get("/excel/"+sheet)

 rows.value=res.data

 if(res.data.length)
  headers.value=Object.keys(res.data[0])

}

async function remove(row){

 await api.delete("/excel/"+sheet+"/"+row.id)

 await load()

}

onMounted(load)

</script>
