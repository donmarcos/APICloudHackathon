
<template>

<div>

<h2>Worksheets</h2>

<ul>
<li v-for="w in sheets">
<router-link :to="'/sheet/'+w">{{w}}</router-link>
</li>
</ul>

</div>

</template>

<script setup>

import {ref,onMounted} from "vue"
import api from "../services/api"

const sheets=ref([])

onMounted(async()=>{

 const res=await api.get("/excel/worksheets")

 sheets.value=res.data

})

</script>
