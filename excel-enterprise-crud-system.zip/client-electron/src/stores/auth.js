
import {defineStore} from "pinia"
import api from "../services/api"

export const useAuth=defineStore("auth",{

 state:()=>({user:null,token:null}),

 actions:{

 async login(username,password){

  const res=await api.post("/auth/login",{username,password})

  this.user=res.data.user
  this.token=res.data.token

 }

 }

})
