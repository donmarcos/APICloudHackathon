
<template>

<div>

<input v-model="search" placeholder="Search"/>

<table border="1" width="100%">

<tr>
<th v-for="h in headers">{{h}}</th>
<th>Actions</th>
</tr>

<tr v-for="row in filteredRows">

<td v-for="h in headers">{{row[h]}}</td>

<td>
<button @click="$emit('edit',row)">Edit</button>
<button @click="$emit('delete',row)">Delete</button>
</td>

</tr>

</table>

</div>

</template>

<script setup>

import {ref,computed} from "vue"

const props=defineProps({rows:Array,headers:Array})

const search=ref("")

const filteredRows=computed(()=>{

 if(!search.value) return props.rows

 return props.rows.filter(r=>
  JSON.stringify(r).toLowerCase().includes(search.value.toLowerCase())
 )

})

</script>
