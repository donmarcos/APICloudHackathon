
# Enterprise Excel CRUD System

Architecture

Electron
   └ Vue 3 Client
        └ REST API
              └ Node Server
                    └ Excel Backend

Features
- Electron desktop application
- Vue3 + Pinia
- Vuetify UI
- Role permissions
- JWT authentication
- REST CRUD
- Websocket notifications
- ExcelJS backend
- Docker deployment
- Configurable ENV variables

Run Server

cd server
npm install
npm start

Run Client

cd client-electron
npm install
npm run dev
npm run electron
