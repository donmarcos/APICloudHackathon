
Enterprise Excel CRUD Platform - Version 2

Major features

• Electron Desktop Client
• Vue3 + Pinia
• Vuetify Enterprise UI
• Inline grid editing
• Search filtering
• Role based permissions
• JWT authentication
• Active Directory optional authentication
• ExcelJS backend
• WebSocket notifications
• Audit logging
• Excel schema auto detection
• Import / Export
• Docker deployment

Run Server
cd server
npm install
npm start

Run Client
cd client-electron
npm install
npm run dev
npm run electron
