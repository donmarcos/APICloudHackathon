
const router=require("express").Router()
const fs=require("fs")

router.get("/",(req,res)=>{

const log=fs.readFileSync("./logs/audit.log","utf8")

res.json(log.split("\n").filter(Boolean))

})

module.exports=router
