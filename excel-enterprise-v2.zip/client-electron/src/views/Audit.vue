
<template>

<div>

<h2>Audit Logs</h2>

<ul>
<li v-for="l in logs">{{l}}</li>
</ul>

</div>

</template>

<script setup>

import {ref,onMounted} from "vue"
import api from "../services/api"

const logs=ref([])

onMounted(async()=>{

const res=await api.get("/audit")

logs.value=res.data

})

</script>
