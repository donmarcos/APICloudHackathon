
import {createRouter,createWebHistory} from "vue-router"

import Login from "../views/Login.vue"
import Dashboard from "../views/Dashboard.vue"
import Worksheet from "../views/Worksheet.vue"
import Audit from "../views/Audit.vue"

const routes=[
{path:"/",component:Login},
{path:"/dashboard",component:Dashboard},
{path:"/sheet/:name",component:Worksheet},
{path:"/audit",component:Audit}
]

export default createRouter({
history:createWebHistory(),
routes
})
