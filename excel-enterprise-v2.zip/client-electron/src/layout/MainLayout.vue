
<template>

<div style="display:flex">

<div style="width:240px;background:#1e293b;color:white;height:100vh">

<h3 style="padding:15px">Enterprise Data Platform</h3>

<ul>
<li><router-link to="/dashboard">Dashboard</router-link></li>
<li><router-link to="/audit">Audit Logs</router-link></li>
</ul>

</div>

<div style="flex:1;padding:25px">

<router-view/>

</div>

</div>

</template>
