
const express=require("express")
const cors=require("cors")
const http=require("http")
const socketio=require("socket.io")

require("dotenv").config()

const authRoutes=require("./routes/auth")
const excelRoutes=require("./routes/excel")
const auditRoutes=require("./routes/audit")
const importRoutes=require("./routes/import")

const app=express()
const server=http.createServer(app)
const io=socketio(server,{cors:{origin:"*"}})

app.use(cors())
app.use(express.json())

app.use("/auth",authRoutes)
app.use("/excel",excelRoutes(io))
app.use("/audit",auditRoutes)
app.use("/import",importRoutes)

server.listen(process.env.PORT,()=>{
console.log("Enterprise V3 server running")
})
