
const fs=require("fs")

function log(msg){

fs.appendFileSync("./logs/audit.log",msg+"\n")

}

module.exports={log}
