
const Excel=require("exceljs")

async function load(){

const wb=new Excel.Workbook()
await wb.xlsx.readFile(process.env.EXCEL_FILE_PATH)
return wb

}

async function getSheets(){

const wb=await load()
return wb.worksheets.map(w=>w.name)

}

async function read(sheet){

const wb=await load()
const ws=wb.getWorksheet(sheet)

const headers=[]
ws.getRow(1).eachCell(c=>headers.push(c.value))

const rows=[]

ws.eachRow((row,i)=>{

if(i===1) return

const obj={}

row.eachCell((cell,idx)=>{

obj[headers[idx-1]]=cell.value

})

rows.push(obj)

})

return rows

}

async function updateRow(sheet,id,data){

const wb=await load()
const ws=wb.getWorksheet(sheet)

ws.eachRow((row,i)=>{

if(row.getCell(1).value==id){

Object.values(data).forEach((v,idx)=>{
row.getCell(idx+1).value=v
})

}

})

await wb.xlsx.writeFile(process.env.EXCEL_FILE_PATH)

}

async function deleteRow(sheet,id){

const wb=await load()
const ws=wb.getWorksheet(sheet)

ws.eachRow((row,i)=>{

if(row.getCell(1).value==id){
ws.spliceRows(i,1)
}

})

await wb.xlsx.writeFile(process.env.EXCEL_FILE_PATH)

}

module.exports={getSheets,read,updateRow,deleteRow}
