
const router=require("express").Router()
const multer=require("multer")
const upload=multer({dest:"uploads/"})
const fs=require("fs")

router.post("/",upload.single("file"),async(req,res)=>{

const data=fs.readFileSync(req.file.path,"utf8")
// placeholder import logic

res.json({status:"imported"})

})

module.exports=router
