
const router=require("express").Router()
const fs=require("fs")

router.get("/",(req,res)=>{

try{

const log=fs.readFileSync("./logs/audit.log","utf8")
res.json(log.split("\n").filter(Boolean))

}catch{
res.json([])
}

})

module.exports=router
