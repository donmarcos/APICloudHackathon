
const router=require("express").Router()
const excel=require("../services/excel")
const audit=require("../services/audit")

module.exports=(io)=>{

router.get("/worksheets",async(req,res)=>{

const sheets=await excel.getSheets()
res.json(sheets)

})

router.get("/:sheet",async(req,res)=>{

const rows=await excel.read(req.params.sheet)
res.json(rows)

})

router.put("/:sheet/:id",async(req,res)=>{

await excel.updateRow(req.params.sheet,req.params.id,req.body)
audit.log("update "+req.params.sheet+" id "+req.params.id)

io.emit("excelUpdated",{sheet:req.params.sheet})

res.json({status:"updated"})

})

router.delete("/:sheet/:id",async(req,res)=>{

await excel.deleteRow(req.params.sheet,req.params.id)
audit.log("delete "+req.params.sheet+" id "+req.params.id)

io.emit("excelUpdated",{sheet:req.params.sheet})

res.json({status:"deleted"})

})

return router
}
