
Enterprise Excel Data Platform - Version 3

Major Upgrades

• Electron Desktop Client
• Vue3 + Pinia + Vuetify ready structure
• Role Based Access Control
• Active Directory optional integration
• Advanced Data Grid (inline editing, filters, pagination)
• Import / Export Excel + CSV
• Schema discovery
• Background Excel write queue
• Conflict protection
• Audit logging
• WebSocket live updates
• Docker full stack
• Production packaging scripts

Run Server
cd server
npm install
npm start

Run Client
cd client-electron
npm install
npm run dev
npm run electron
