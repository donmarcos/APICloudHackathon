
import {createRouter,createWebHistory} from "vue-router"

import Login from "../views/Login.vue"
import Dashboard from "../views/Dashboard.vue"
import Worksheet from "../views/Worksheet.vue"
import Audit from "../views/Audit.vue"
import Import from "../views/Import.vue"

const routes=[
{path:"/",component:Login},
{path:"/dashboard",component:Dashboard},
{path:"/sheet/:name",component:Worksheet},
{path:"/audit",component:Audit},
{path:"/import",component:Import}
]

export default createRouter({
history:createWebHistory(),
routes
})
