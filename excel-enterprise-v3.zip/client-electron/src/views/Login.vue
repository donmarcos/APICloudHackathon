
<template>

<div>

<h2>Login</h2>

<input v-model="username" placeholder="username"/>
<input v-model="password" type="password"/>

<button @click="login">Login</button>

</div>

</template>

<script setup>

import {ref} from "vue"
import {useRouter} from "vue-router"
import api from "../services/api"

const username=ref("")
const password=ref("")
const router=useRouter()

async function login(){

await api.post("/auth/login",{username:username.value,password:password.value})
router.push("/dashboard")

}

</script>
